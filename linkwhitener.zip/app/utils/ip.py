from fastapi import Request


def get_client_ip(request: Request) -> str:
    """
    Extract real client IP address.
    Works behind proxies / load balancers.
    """

    # AWS / Nginx / Cloudflare
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        # Take first IP in list
        return forwarded_for.split(",")[0].strip()

    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip

    if request.client:
        return request.client.host

    return "0.0.0.0"
