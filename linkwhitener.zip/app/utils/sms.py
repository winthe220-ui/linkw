from app.core.logging import logger


def send_sms(
    phone_number: str,
    message: str,
):
    """
    SMS sending placeholder.

    Replace with:
    - Firebase OTP
    - Twilio
    - AWS SNS
    when required.
    """

    logger.info(
        f"[SMS] To={phone_number} | Message={message}"
    )

    # No external provider call
    return True
