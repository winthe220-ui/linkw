import secrets
import hashlib


# -----------------------------
# GENERATE RANDOM TOKEN
# -----------------------------
def generate_token(length: int = 48) -> str:
    """
    Generates a cryptographically secure random token.
    Used for withdraw, reset, internal verification.
    """
    return secrets.token_urlsafe(length)


# -----------------------------
# HASH TOKEN
# -----------------------------
def hash_token(token: str) -> str:
    """
    Hash token before storing in DB.
    """
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


# -----------------------------
# VERIFY TOKEN
# -----------------------------
def verify_token(token: str, token_hash: str) -> bool:
    return hash_token(token) == token_hash
