from app.core.logging import logger


def send_email(
    to_email: str,
    subject: str,
    body: str,
):
    """
    Email sending placeholder.

    Replace this with:
    - AWS SES
    - SMTP
    - SendGrid
    when ready.
    """

    logger.info(
        f"[EMAIL] To={to_email} | Subject={subject} | Body={body}"
    )

    # Intentionally no external call
    return True
