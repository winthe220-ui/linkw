import sys
from loguru import logger
from pathlib import Path

# -----------------------------
# LOG DIRECTORY
# -----------------------------
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

APP_LOG = LOG_DIR / "app.log"
SECURITY_LOG = LOG_DIR / "security.log"

# -----------------------------
# REMOVE DEFAULT LOGGER
# -----------------------------
logger.remove()

# -----------------------------
# APP LOGGING
# -----------------------------
logger.add(
    sys.stdout,
    level="INFO",
    format="<green>{time}</green> | <level>{level}</level> | {message}",
)

logger.add(
    APP_LOG,
    level="INFO",
    rotation="10 MB",
    retention="30 days",
    compression="zip",
    enqueue=True,
)

# -----------------------------
# SECURITY / AUDIT LOGGING
# -----------------------------
security_logger = logger.bind(type="security")

security_logger.add(
    SECURITY_LOG,
    level="WARNING",
    rotation="5 MB",
    retention="30 days",
    compression="zip",
    enqueue=True,
)

# -----------------------------
# HELPERS
# -----------------------------
def log_security_event(
    message: str,
    actor_type: str = "system",
    actor_id: int | None = None,
    ip: str | None = None,
):
    security_logger.warning(
        f"{message} | actor={actor_type} | id={actor_id} | ip={ip}"
    )
