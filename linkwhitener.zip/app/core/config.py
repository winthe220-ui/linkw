from pydantic_settings import BaseSettings
from pydantic import Field
from typing import List
import os


class Settings(BaseSettings):
    # -----------------------------
    # APP
    # -----------------------------
    APP_NAME: str = "LinkWhitener Backend"
    ENVIRONMENT: str = "production"
    DEBUG: bool = False

    # -----------------------------
    # DATABASE
    # -----------------------------
    DATABASE_URL: str = Field(...)

    # -----------------------------
    # JWT USER
    # -----------------------------
    JWT_SECRET_KEY: str = Field(..., min_length=32)
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # -----------------------------
    # JWT ADMIN
    # -----------------------------
    ADMIN_JWT_SECRET_KEY: str = Field(..., min_length=32)
    ADMIN_JWT_EXPIRE_MINUTES: int = 720

    # -----------------------------
    # TOKENS
    # -----------------------------
    WITHDRAW_TOKEN_EXPIRE_HOURS: int = 72
    PASSWORD_RESET_TOKEN_EXPIRE_MINUTES: int = 30

    # -----------------------------
    # RATE LIMIT
    # -----------------------------
    RATE_LIMIT_PER_MINUTE: int = 100
    LOGIN_ATTEMPT_LIMIT: int = 5
    LOGIN_LOCK_MINUTES: int = 15

    # -----------------------------
    # BUSINESS LOGIC
    # -----------------------------
    EARNING_PER_1000_CLICKS: float = 3.0
    MIN_WITHDRAW_AMOUNT: float = 5.0

    # -----------------------------
    # SECURITY
    # -----------------------------
    ALLOWED_CORS_ORIGINS: List[str] = []
    ENABLE_HTTPS_ONLY: bool = True

    # -----------------------------
    # CLEANUP
    # -----------------------------
    DATA_RETENTION_HOURS: int = 48
    AUDIT_LOG_RETENTION_DAYS: int = 30
    DAILY_BACKUP_HOUR_UTC: int = 2

    # -----------------------------
    # EMAIL / SMS
    # -----------------------------
    EMAIL_SENDER: str = "no-reply@linkwhitener.online"
    SMS_PROVIDER: str = "disabled"

    class Config:
        env_file = ".env"
        case_sensitive = True


# Load settings once
settings = Settings()

# -----------------------------
# HARD FAILS (IMPORTANT)
# -----------------------------
if settings.ENVIRONMENT == "production" and settings.DEBUG:
    raise RuntimeError("DEBUG must be false in production")

if len(settings.JWT_SECRET_KEY) < 32:
    raise RuntimeError("JWT_SECRET_KEY too short")

if len(settings.ADMIN_JWT_SECRET_KEY) < 32:
    raise RuntimeError("ADMIN_JWT_SECRET_KEY too short")
