from slowapi import Limiter
from slowapi.util import get_remote_address

from app.core.config import settings

# Global limiter instance
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=[f"{settings.RATE_LIMIT_PER_MINUTE}/minute"],
)

# Named limits (reusable)
LIMIT_AUTH_STRICT = "5/minute"
LIMIT_AUTH_NORMAL = "10/minute"
LIMIT_GENERAL = f"{settings.RATE_LIMIT_PER_MINUTE}/minute"
