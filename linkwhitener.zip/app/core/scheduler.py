from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from sqlalchemy.orm import Session

from app.database.session import SessionLocal
from app.core.config import settings
from app.core.logging import logger

from app.models.click import Click
from app.models.audit import AuditLog


scheduler = BackgroundScheduler(timezone="UTC")


# -----------------------------
# CLEAN OLD CLICKS (48 HOURS)
# -----------------------------
def cleanup_old_clicks():
    db: Session = SessionLocal()
    try:
        cutoff = datetime.utcnow() - timedelta(hours=settings.DATA_RETENTION_HOURS)

        deleted = (
            db.query(Click)
            .filter(Click.created_at < cutoff)
            .delete(synchronize_session=False)
        )

        db.commit()
        logger.info(f"Cleanup: removed {deleted} old clicks")

    except Exception as e:
        logger.error(f"Cleanup old clicks failed: {e}")
    finally:
        db.close()


# -----------------------------
# CLEAN AUDIT LOGS (30 DAYS)
# -----------------------------
def cleanup_audit_logs():
    db: Session = SessionLocal()
    try:
        cutoff = datetime.utcnow() - timedelta(
            days=settings.AUDIT_LOG_RETENTION_DAYS
        )

        deleted = (
            db.query(AuditLog)
            .filter(AuditLog.created_at < cutoff)
            .delete(synchronize_session=False)
        )

        db.commit()
        logger.info(f"Cleanup: removed {deleted} audit logs")

    except Exception as e:
        logger.error(f"Cleanup audit logs failed: {e}")
    finally:
        db.close()


# -----------------------------
# DAILY BACKUP PLACEHOLDER
# -----------------------------
def daily_backup():
    """
    Hook this to:
    - pg_dump
    - S3 upload
    - snapshot trigger
    """
    logger.info("Daily backup job executed (hook placeholder)")


# -----------------------------
# START SCHEDULER
# -----------------------------
def start_scheduler():
    if scheduler.running:
        return

    scheduler.add_job(
        cleanup_old_clicks,
        trigger="interval",
        hours=6,
        id="cleanup_old_clicks",
        replace_existing=True,
    )

    scheduler.add_job(
        cleanup_audit_logs,
        trigger="interval",
        hours=24,
        id="cleanup_audit_logs",
        replace_existing=True,
    )

    scheduler.add_job(
        daily_backup,
        trigger="cron",
        hour=settings.DAILY_BACKUP_HOUR_UTC,
        minute=0,
        id="daily_backup",
        replace_existing=True,
    )

    scheduler.start()
    logger.info("Background scheduler started")
