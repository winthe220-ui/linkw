from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import secrets
import hashlib

from jose import jwt, JWTError
from passlib.context import CryptContext

from app.core.config import settings

# -----------------------------
# PASSWORD HASHING
# -----------------------------
pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
)


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    return pwd_context.verify(password, password_hash)


# -----------------------------
# JWT CREATION (USER)
# -----------------------------
def create_user_access_token(subject: str, extra: Optional[Dict[str, Any]] = None) -> str:
    expire = datetime.utcnow() + timedelta(
        minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES
    )
    payload = {
        "sub": subject,
        "exp": expire,
        "type": "user",
    }
    if extra:
        payload.update(extra)

    return jwt.encode(
        payload,
        settings.JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM,
    )


def create_user_refresh_token(subject: str) -> str:
    expire = datetime.utcnow() + timedelta(
        days=settings.JWT_REFRESH_TOKEN_EXPIRE_DAYS
    )
    payload = {
        "sub": subject,
        "exp": expire,
        "type": "refresh",
    }

    return jwt.encode(
        payload,
        settings.JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM,
    )


# -----------------------------
# JWT CREATION (ADMIN)
# -----------------------------
def create_admin_access_token(subject: str) -> str:
    expire = datetime.utcnow() + timedelta(
        minutes=settings.ADMIN_JWT_EXPIRE_MINUTES
    )
    payload = {
        "sub": subject,
        "exp": expire,
        "type": "admin",
    }

    return jwt.encode(
        payload,
        settings.ADMIN_JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM,
    )


# -----------------------------
# JWT DECODE
# -----------------------------
def decode_user_token(token: str) -> Dict[str, Any]:
    try:
        payload = jwt.decode(
            token,
            settings.JWT_SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
        if payload.get("type") not in ("user", "refresh"):
            raise JWTError("Invalid token type")
        return payload
    except JWTError:
        raise ValueError("Invalid or expired token")


def decode_admin_token(token: str) -> Dict[str, Any]:
    try:
        payload = jwt.decode(
            token,
            settings.ADMIN_JWT_SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
        if payload.get("type") != "admin":
            raise JWTError("Invalid admin token")
        return payload
    except JWTError:
        raise ValueError("Invalid or expired admin token")


# -----------------------------
# ONE-TIME TOKENS (WITHDRAW / RESET)
# -----------------------------
def generate_plain_token(length: int = 48) -> str:
    """
    Generates a cryptographically secure random token
    (this is shown ONCE to the user).
    """
    return secrets.token_urlsafe(length)


def hash_token(token: str) -> str:
    """
    Hash token before storing in DB.
    """
    return hashlib.sha256(token.encode()).hexdigest()


def verify_token(token: str, token_hash: str) -> bool:
    return hash_token(token) == token_hash
