from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional


# -----------------------------
# USER WITHDRAW REQUEST
# -----------------------------
class WithdrawRequest(BaseModel):
    amount: float = Field(..., gt=0)
    withdraw_token: str = Field(..., min_length=10)
    upi_id: Optional[str] = None
    bank_account: Optional[str] = None


# -----------------------------
# USER WITHDRAW RESPONSE
# -----------------------------
class WithdrawalResponse(BaseModel):
    id: int
    amount: float
    is_approved: bool
    is_rejected: bool
    created_at: datetime
    processed_at: Optional[datetime]

    class Config:
        from_attributes = True


# -----------------------------
# ADMIN WITHDRAW VIEW
# -----------------------------
class AdminWithdrawalResponse(BaseModel):
    id: int
    user_id: int
    amount: float
    upi_id: Optional[str]
    bank_account: Optional[str]
    is_approved: bool
    is_rejected: bool
    processed_by_admin: Optional[str]
    created_at: datetime
    processed_at: Optional[datetime]

    class Config:
        from_attributes = True
