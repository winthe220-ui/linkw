from pydantic import BaseModel, HttpUrl
from datetime import datetime
from typing import Optional


# -----------------------------
# CREATE LINK
# -----------------------------
class CreateLinkRequest(BaseModel):
    original_url: HttpUrl
    public_name: Optional[str] = None


# -----------------------------
# USER LINK RESPONSE
# -----------------------------
class LinkResponse(BaseModel):
    id: int
    short_code: str
    original_url: str
    public_name: Optional[str]
    total_clicks: int
    valid_clicks: int
    invalid_clicks: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# -----------------------------
# ADMIN LINK VIEW
# -----------------------------
class AdminLinkResponse(BaseModel):
    id: int
    user_id: int
    short_code: str
    original_url: str
    total_clicks: int
    valid_clicks: int
    invalid_clicks: int
    is_active: bool
    is_deleted: bool
    created_at: datetime

    class Config:
        from_attributes = True
