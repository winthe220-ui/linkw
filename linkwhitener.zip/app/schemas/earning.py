from pydantic import BaseModel
from datetime import datetime


# -----------------------------
# USER BALANCE
# -----------------------------
class BalanceResponse(BaseModel):
    balance: float
    total_earned: float
    total_withdrawn: float


# -----------------------------
# EARNING HISTORY
# -----------------------------
class EarningHistoryResponse(BaseModel):
    id: int
    amount: float
    clicks_count: int
    is_paid: bool
    created_at: datetime

    class Config:
        from_attributes = True


# -----------------------------
# ADMIN EARNING VIEW
# -----------------------------
class AdminEarningResponse(BaseModel):
    id: int
    user_id: int
    amount: float
    clicks_count: int
    is_paid: bool
    created_at: datetime

    class Config:
        from_attributes = True
