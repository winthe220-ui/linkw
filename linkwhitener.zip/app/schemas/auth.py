from pydantic import BaseModel, Field, EmailStr


# -----------------------------
# REGISTER
# -----------------------------
class RegisterRequest(BaseModel):
    phone_number: str = Field(..., min_length=8, max_length=20)
    password: str = Field(..., min_length=8)
    email: EmailStr | None = None


class RegisterResponse(BaseModel):
    message: str
    user_id: int


# -----------------------------
# LOGIN
# -----------------------------
class LoginRequest(BaseModel):
    phone_number: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


# -----------------------------
# TOKEN GENERATION
# -----------------------------
class OneTimeTokenResponse(BaseModel):
    token: str
    warning: str
