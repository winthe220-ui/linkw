from pydantic import BaseModel
from datetime import datetime
from typing import Optional

from app.models.user import MembershipType


# -----------------------------
# USER DASHBOARD
# -----------------------------
class UserDashboardResponse(BaseModel):
    id: int
    phone_number: str
    email: Optional[str]
    membership: MembershipType
    balance: float
    total_earned: float
    total_withdrawn: float
    is_verified: bool
    created_at: datetime

    class Config:
        from_attributes = True


# -----------------------------
# PUBLIC USER (LIMITED)
# -----------------------------
class PublicUserResponse(BaseModel):
    id: int
    phone_number: str
    membership: MembershipType

    class Config:
        from_attributes = True


# -----------------------------
# ADMIN VIEW USER
# -----------------------------
class AdminUserResponse(BaseModel):
    id: int
    phone_number: str
    email: Optional[str]
    membership: MembershipType
    balance: float
    total_earned: float
    total_withdrawn: float
    is_active: bool
    is_blocked: bool
    failed_login_attempts: int
    locked_until: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True
