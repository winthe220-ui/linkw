from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.user import User, MembershipType
from app.core.security import (
    hash_password,
    verify_password,
    create_user_access_token,
    create_user_refresh_token,
    generate_plain_token,
    hash_token,
)
from app.core.config import settings


# -----------------------------
# REGISTER USER
# -----------------------------
def register_user(
    db: Session,
    phone_number: str,
    password: str,
    email: str | None = None,
) -> User:
    existing = (
        db.query(User)
        .filter((User.phone_number == phone_number) | (User.email == email))
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User already exists",
        )

    user = User(
        phone_number=phone_number,
        email=email,
        password_hash=hash_password(password),
        membership=MembershipType.free,
        is_verified=True,  # OTP verification hook here
    )

    db.add(user)
    db.commit()
    db.refresh(user)
    return user


# -----------------------------
# LOGIN USER
# -----------------------------
def login_user(db: Session, phone_number: str, password: str):
    user = db.query(User).filter(User.phone_number == phone_number).first()

    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Check lock
    if user.locked_until and user.locked_until > datetime.utcnow():
        raise HTTPException(
            status_code=403,
            detail="Account locked. Try later.",
        )

    if not verify_password(password, user.password_hash):
        user.failed_login_attempts += 1

        if user.failed_login_attempts >= settings.LOGIN_ATTEMPT_LIMIT:
            user.locked_until = datetime.utcnow() + timedelta(
                minutes=settings.LOGIN_LOCK_MINUTES
            )
            user.failed_login_attempts = 0

        db.commit()
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Reset failed attempts
    user.failed_login_attempts = 0
    user.locked_until = None

    db.commit()

    access_token = create_user_access_token(subject=str(user.id))
    refresh_token = create_user_refresh_token(subject=str(user.id))

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
    }


# -----------------------------
# GENERATE WITHDRAW TOKEN
# -----------------------------
def generate_withdraw_token(db: Session, user: User) -> str:
    plain_token = generate_plain_token()
    user.withdraw_token_hash = hash_token(plain_token)
    db.commit()
    return plain_token


# -----------------------------
# PASSWORD RESET REQUEST
# -----------------------------
def generate_password_reset_token(db: Session, user: User) -> str:
    plain_token = generate_plain_token()
    user.reset_token_hash = hash_token(plain_token)
    db.commit()
    return plain_token
