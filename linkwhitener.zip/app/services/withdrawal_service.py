from datetime import datetime
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.user import User
from app.models.withdrawal import Withdrawal
from app.core.security import verify_token, hash_token
from app.core.config import settings


# -----------------------------
# REQUEST WITHDRAWAL
# -----------------------------
def request_withdrawal(
    db: Session,
    user: User,
    amount: float,
    withdraw_token: str,
    upi_id: str | None = None,
    bank_account: str | None = None,
):
    # Minimum withdrawal enforcement
    if amount < settings.MIN_WITHDRAW_AMOUNT:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Minimum withdrawal amount is {settings.MIN_WITHDRAW_AMOUNT}",
        )

    # Balance check
    if user.balance < amount:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Insufficient balance",
        )

    # Token verification
    if not user.withdraw_token_hash:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Withdraw token not generated",
        )

    if not verify_token(withdraw_token, user.withdraw_token_hash):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid withdraw token",
        )

    # Deduct balance immediately (lock funds)
    user.balance -= amount
    user.total_withdrawn += amount

    withdrawal = Withdrawal(
        user_id=user.id,
        amount=amount,
        upi_id=upi_id,
        bank_account=bank_account,
    )

    # Invalidate token after use
    user.withdraw_token_hash = None

    db.add(withdrawal)
    db.commit()
    db.refresh(withdrawal)

    return withdrawal


# -----------------------------
# ADMIN: APPROVE WITHDRAWAL
# -----------------------------
def approve_withdrawal(
    db: Session,
    withdrawal: Withdrawal,
    admin_username: str,
):
    if withdrawal.is_approved or withdrawal.is_rejected:
        raise HTTPException(status_code=400, detail="Already processed")

    withdrawal.is_approved = True
    withdrawal.processed_by_admin = admin_username
    withdrawal.processed_at = datetime.utcnow()
    db.commit()


# -----------------------------
# ADMIN: REJECT WITHDRAWAL
# -----------------------------
def reject_withdrawal(
    db: Session,
    withdrawal: Withdrawal,
    admin_username: str,
    user: User,
):
    if withdrawal.is_approved or withdrawal.is_rejected:
        raise HTTPException(status_code=400, detail="Already processed")

    # Refund user
    user.balance += withdrawal.amount
    user.total_withdrawn -= withdrawal.amount

    withdrawal.is_rejected = True
    withdrawal.processed_by_admin = admin_username
    withdrawal.processed_at = datetime.utcnow()

    db.commit()
