import string
import secrets
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.link import Link
from app.models.user import User, MembershipType

# -----------------------------
# MEMBERSHIP LIMITS
# -----------------------------
MEMBERSHIP_LIMITS = {
    MembershipType.free: 150,
    MembershipType.pro: 1000,
    MembershipType.elite: 10000,
}


# -----------------------------
# SHORT CODE GENERATOR
# -----------------------------
def generate_short_code(length: int = 8) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def generate_unique_code(db: Session) -> str:
    """
    Ensures no collision even at massive scale.
    """
    while True:
        code = generate_short_code(8)
        exists = db.query(Link).filter(Link.short_code == code).first()
        if not exists:
            return code


# -----------------------------
# CREATE LINK
# -----------------------------
def create_link(
    db: Session,
    user: User,
    original_url: str,
    public_name: str | None = None,
) -> Link:
    # Membership limit enforcement
    limit = MEMBERSHIP_LIMITS.get(user.membership, 150)

    current_count = (
        db.query(Link)
        .filter(Link.user_id == user.id, Link.is_deleted == False)
        .count()
    )

    if current_count >= limit:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Link creation limit reached for your membership",
        )

    short_code = generate_unique_code(db)

    link = Link(
        user_id=user.id,
        short_code=short_code,
        original_url=original_url,
        public_name=public_name,
    )

    db.add(link)
    db.commit()
    db.refresh(link)
    return link


# -----------------------------
# DELETE LINK (SOFT)
# -----------------------------
def delete_link(db: Session, user: User, link_id: int):
    link = (
        db.query(Link)
        .filter(Link.id == link_id, Link.user_id == user.id)
        .first()
    )
    if not link:
        raise HTTPException(status_code=404, detail="Link not found")

    link.is_deleted = True
    link.is_active = False
    db.commit()
