from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from datetime import datetime

from app.models.admin import Admin
from app.models.user import User
from app.models.withdrawal import Withdrawal
from app.core.security import verify_password, create_admin_access_token
from app.core.logging import log_security_event


# -----------------------------
# ADMIN LOGIN
# -----------------------------
def admin_login_service(
    db: Session,
    username: str,
    password: str,
    ip: str | None = None,
):
    admin = db.query(Admin).filter(Admin.username == username).first()

    if not admin or not admin.is_active:
        log_security_event(
            "Invalid admin login attempt",
            actor_type="admin",
            actor_id=None,
            ip=ip,
        )
        raise HTTPException(status_code=401, detail="Invalid credentials")

    if not verify_password(password, admin.password_hash):
        admin.failed_login_attempts += 1
        db.commit()
        raise HTTPException(status_code=401, detail="Invalid credentials")

    admin.failed_login_attempts = 0
    admin.last_login = datetime.utcnow()
    db.commit()

    token = create_admin_access_token(subject=str(admin.id))
    return token


# -----------------------------
# APPROVE WITHDRAWAL
# -----------------------------
def admin_approve_withdrawal(
    db: Session,
    admin: Admin,
    withdrawal_id: int,
):
    withdrawal = (
        db.query(Withdrawal)
        .filter(Withdrawal.id == withdrawal_id)
        .first()
    )
    if not withdrawal:
        raise HTTPException(status_code=404, detail="Withdrawal not found")

    if withdrawal.is_approved or withdrawal.is_rejected:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Withdrawal already processed",
        )

    withdrawal.is_approved = True
    withdrawal.processed_by_admin = admin.username
    withdrawal.processed_at = datetime.utcnow()

    db.commit()

    log_security_event(
        "Withdrawal approved",
        actor_type="admin",
        actor_id=admin.id,
    )

    return withdrawal


# -----------------------------
# REJECT WITHDRAWAL
# -----------------------------
def admin_reject_withdrawal(
    db: Session,
    admin: Admin,
    withdrawal_id: int,
):
    withdrawal = (
        db.query(Withdrawal)
        .filter(Withdrawal.id == withdrawal_id)
        .first()
    )
    if not withdrawal:
        raise HTTPException(status_code=404, detail="Withdrawal not found")

    if withdrawal.is_approved or withdrawal.is_rejected:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Withdrawal already processed",
        )

    user = db.query(User).filter(User.id == withdrawal.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Refund
    user.balance += withdrawal.amount
    user.total_withdrawn -= withdrawal.amount

    withdrawal.is_rejected = True
    withdrawal.processed_by_admin = admin.username
    withdrawal.processed_at = datetime.utcnow()

    db.commit()

    log_security_event(
        "Withdrawal rejected",
        actor_type="admin",
        actor_id=admin.id,
    )

    return withdrawal
