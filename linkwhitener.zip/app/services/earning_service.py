from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models.click import Click
from app.models.earning import Earning
from app.models.user import User
from app.core.config import settings


# -----------------------------
# PROCESS EARNINGS FOR USER
# -----------------------------
def process_user_earnings(db: Session, user: User):
    """
    Converts unprocessed valid clicks into earnings.
    This should be called periodically or on-demand.
    """

    # Fetch valid clicks that are not yet counted
    valid_clicks = (
        db.query(Click)
        .filter(
            Click.user_id == user.id,
            Click.is_valid == True,
        )
        .all()
    )

    if not valid_clicks:
        return {"message": "No new earnings"}

    click_count = len(valid_clicks)

    # Calculate earning
    amount = (click_count / 1000) * settings.EARNING_PER_1000_CLICKS

    if amount <= 0:
        return {"message": "Insufficient clicks for earnings"}

    # Create earning record
    earning = Earning(
        user_id=user.id,
        amount=amount,
        clicks_count=click_count,
    )

    # Update user wallet
    user.balance += amount
    user.total_earned += amount

    # Mark clicks as processed (invalidate further counting)
    for click in valid_clicks:
        click.is_valid = False  # prevents double credit

    db.add(earning)
    db.commit()

    return {
        "clicks_processed": click_count,
        "amount_earned": amount,
        "current_balance": user.balance,
    }
