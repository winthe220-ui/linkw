from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field

from app.database.session import get_db
from app.api.deps import get_current_user
from app.services.withdrawal_service import request_withdrawal
from app.models.user import User
from app.models.withdrawal import Withdrawal

router = APIRouter()


# -----------------------------
# SCHEMAS
# -----------------------------
class WithdrawRequest(BaseModel):
    amount: float = Field(..., gt=0)
    withdraw_token: str = Field(..., min_length=10)
    upi_id: str | None = None
    bank_account: str | None = None


class WithdrawalResponse(BaseModel):
    id: int
    amount: float
    is_approved: bool
    is_rejected: bool
    created_at: str

    class Config:
        from_attributes = True


# -----------------------------
# REQUEST WITHDRAWAL
# -----------------------------
@router.post("/request", response_model=WithdrawalResponse)
def request_user_withdrawal(
    payload: WithdrawRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    withdrawal = request_withdrawal(
        db=db,
        user=user,
        amount=payload.amount,
        withdraw_token=payload.withdraw_token,
        upi_id=payload.upi_id,
        bank_account=payload.bank_account,
    )
    return withdrawal


# -----------------------------
# WITHDRAWAL HISTORY
# -----------------------------
@router.get("/history", response_model=list[WithdrawalResponse])
def withdrawal_history(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    withdrawals = (
        db.query(Withdrawal)
        .filter(Withdrawal.user_id == user.id)
        .order_by(Withdrawal.created_at.desc())
        .all()
    )
    return withdrawals
