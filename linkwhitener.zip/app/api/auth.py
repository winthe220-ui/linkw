from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from slowapi import Limiter
from slowapi.util import get_remote_address
from pydantic import BaseModel, Field

from app.database.session import get_db
from app.services.auth_service import (
    register_user,
    login_user,
    generate_withdraw_token,
    generate_password_reset_token,
)
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter()
limiter = Limiter(key_func=get_remote_address)

# -----------------------------
# SCHEMAS
# -----------------------------
class RegisterRequest(BaseModel):
    phone_number: str = Field(..., min_length=8, max_length=20)
    password: str = Field(..., min_length=8)
    email: str | None = None


class LoginRequest(BaseModel):
    phone_number: str
    password: str


# -----------------------------
# REGISTER
# -----------------------------
@router.post("/register")
@limiter.limit("5/minute")
def register(
    request: Request,
    payload: RegisterRequest,
    db: Session = Depends(get_db),
):
    user = register_user(
        db=db,
        phone_number=payload.phone_number,
        password=payload.password,
        email=payload.email,
    )

    return {
        "message": "Registration successful",
        "user_id": user.id,
    }


# -----------------------------
# LOGIN
# -----------------------------
@router.post("/login")
@limiter.limit("10/minute")
def login(
    request: Request,
    payload: LoginRequest,
    db: Session = Depends(get_db),
):
    tokens = login_user(
        db=db,
        phone_number=payload.phone_number,
        password=payload.password,
    )
    return tokens


# -----------------------------
# GENERATE WITHDRAW TOKEN
# -----------------------------
@router.post("/withdraw-token")
def withdraw_token(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    token = generate_withdraw_token(db=db, user=user)
    return {
        "withdraw_token": token,
        "warning": "Store this token securely. It will not be shown again.",
    }


# -----------------------------
# PASSWORD RESET REQUEST
# -----------------------------
@router.post("/reset-token")
def reset_token(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    token = generate_password_reset_token(db=db, user=user)
    return {
        "reset_token": token,
        "expires_in_minutes": 30,
        "warning": "Token shown once only.",
    }
