from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.database.session import get_db
from app.api.deps import get_current_user
from app.services.earning_service import process_user_earnings
from app.models.user import User
from app.models.earning import Earning

router = APIRouter()


# -----------------------------
# SCHEMAS
# -----------------------------
class BalanceResponse(BaseModel):
    balance: float
    total_earned: float
    total_withdrawn: float


class EarningHistoryResponse(BaseModel):
    amount: float
    clicks_count: int
    created_at: str

    class Config:
        from_attributes = True


# -----------------------------
# GET BALANCE
# -----------------------------
@router.get("/balance", response_model=BalanceResponse)
def get_balance(
    user: User = Depends(get_current_user),
):
    return {
        "balance": user.balance,
        "total_earned": user.total_earned,
        "total_withdrawn": user.total_withdrawn,
    }


# -----------------------------
# PROCESS EARNINGS
# -----------------------------
@router.post("/process")
def process_earnings(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    result = process_user_earnings(db=db, user=user)
    return result


# -----------------------------
# EARNING HISTORY
# -----------------------------
@router.get("/history", response_model=list[EarningHistoryResponse])
def earning_history(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    earnings = (
        db.query(Earning)
        .filter(Earning.user_id == user.id)
        .order_by(Earning.created_at.desc())
        .all()
    )
    return earnings
