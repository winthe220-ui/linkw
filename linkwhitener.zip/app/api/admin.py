from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.database.session import get_db
from app.api.deps import get_current_admin
from app.core.security import (
    verify_password,
    hash_password,
    create_admin_access_token,
)
from app.models.admin import Admin
from app.models.user import User
from app.models.withdrawal import Withdrawal
from app.services.withdrawal_service import approve_withdrawal, reject_withdrawal

router = APIRouter()


# -----------------------------
# SCHEMAS
# -----------------------------
class AdminLoginRequest(BaseModel):
    username: str
    password: str


class AdminTokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


# -----------------------------
# ADMIN LOGIN
# -----------------------------
@router.post("/login", response_model=AdminTokenResponse)
def admin_login(
    payload: AdminLoginRequest,
    db: Session = Depends(get_db),
):
    admin = db.query(Admin).filter(Admin.username == payload.username).first()

    if not admin or not admin.is_active:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    if not verify_password(payload.password, admin.password_hash):
        admin.failed_login_attempts += 1
        db.commit()
        raise HTTPException(status_code=401, detail="Invalid credentials")

    admin.failed_login_attempts = 0
    db.commit()

    token = create_admin_access_token(subject=str(admin.id))
    return {"access_token": token}


# -----------------------------
# LIST USERS
# -----------------------------
@router.get("/users")
def list_users(
    admin: Admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    users = db.query(User).order_by(User.created_at.desc()).all()
    return users


# -----------------------------
# LIST WITHDRAWALS
# -----------------------------
@router.get("/withdrawals")
def list_withdrawals(
    admin: Admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    withdrawals = (
        db.query(Withdrawal)
        .order_by(Withdrawal.created_at.desc())
        .all()
    )
    return withdrawals


# -----------------------------
# APPROVE WITHDRAWAL
# -----------------------------
@router.post("/withdrawals/{withdrawal_id}/approve")
def approve(
    withdrawal_id: int,
    admin: Admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    withdrawal = db.query(Withdrawal).filter(Withdrawal.id == withdrawal_id).first()
    if not withdrawal:
        raise HTTPException(status_code=404, detail="Withdrawal not found")

    approve_withdrawal(
        db=db,
        withdrawal=withdrawal,
        admin_username=admin.username,
    )

    return {"status": "approved"}


# -----------------------------
# REJECT WITHDRAWAL
# -----------------------------
@router.post("/withdrawals/{withdrawal_id}/reject")
def reject(
    withdrawal_id: int,
    admin: Admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    withdrawal = db.query(Withdrawal).filter(Withdrawal.id == withdrawal_id).first()
    if not withdrawal:
        raise HTTPException(status_code=404, detail="Withdrawal not found")

    user = db.query(User).filter(User.id == withdrawal.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    reject_withdrawal(
        db=db,
        withdrawal=withdrawal,
        admin_username=admin.username,
        user=user,
    )

    return {"status": "rejected"}
