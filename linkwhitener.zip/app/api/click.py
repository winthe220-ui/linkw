from fastapi import APIRouter, Depends, Request, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import and_

from app.database.session import get_db
from app.models.link import Link
from app.models.click import Click
from app.models.user import User
from app.api.deps import get_current_user

router = APIRouter()


# -----------------------------
# INTERNAL: GET CLIENT IP
# -----------------------------
def get_client_ip(request: Request) -> str:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0]
    return request.client.host


# -----------------------------
# PAGE 1
# -----------------------------
@router.get("/page1/{short_code}")
def page_1(
    short_code: str,
    request: Request,
    db: Session = Depends(get_db),
):
    link = (
        db.query(Link)
        .filter(
            Link.short_code == short_code,
            Link.is_active == True,
            Link.is_deleted == False,
        )
        .first()
    )
    if not link:
        raise HTTPException(status_code=404, detail="Link not found")

    ip = get_client_ip(request)
    ua = request.headers.get("User-Agent", "")

    click = Click(
        link_id=link.id,
        user_id=link.user_id,
        ip_address=ip,
        user_agent=ua,
        page_1=True,
    )

    db.add(click)
    db.commit()

    return {
        "message": "Page 1 visited",
        "next": f"/click/page2/{click.id}",
    }


# -----------------------------
# PAGE 2
# -----------------------------
@router.get("/page2/{click_id}")
def page_2(
    click_id: int,
    db: Session = Depends(get_db),
):
    click = db.query(Click).filter(Click.id == click_id).first()
    if not click or not click.page_1:
        raise HTTPException(status_code=400, detail="Invalid flow")

    click.page_2 = True
    db.commit()

    return {
        "message": "Page 2 visited",
        "next": f"/click/page3/{click.id}",
    }


# -----------------------------
# PAGE 3 (MANDATORY)
# -----------------------------
@router.get("/page3/{click_id}")
def page_3(
    click_id: int,
    db: Session = Depends(get_db),
):
    click = db.query(Click).filter(Click.id == click_id).first()
    if not click or not click.page_2:
        raise HTTPException(status_code=400, detail="Invalid flow")

    click.page_3 = True
    db.commit()

    return {
        "message": "Page 3 visited",
        "next": f"/click/redirect/{click.id}",
    }


# -----------------------------
# FINAL REDIRECT
# -----------------------------
@router.get("/redirect/{click_id}")
def redirect_to_target(
    click_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    click = db.query(Click).filter(Click.id == click_id).first()
    if not click or not click.page_3:
        raise HTTPException(status_code=400, detail="Invalid flow")

    link = db.query(Link).filter(Link.id == click.link_id).first()
    if not link:
        raise HTTPException(status_code=404, detail="Link missing")

    # Duplicate IP check
    duplicate = (
        db.query(Click)
        .filter(
            and_(
                Click.link_id == link.id,
                Click.ip_address == click.ip_address,
                Click.is_valid == True,
            )
        )
        .first()
    )

    if duplicate:
        click.is_duplicate = True
        click.is_valid = False
        link.invalid_clicks += 1
    else:
        click.is_valid = True
        click.redirect_completed = True
        link.valid_clicks += 1

    link.total_clicks += 1

    db.commit()

    return {
        "redirect_to": link.original_url,
        "valid": click.is_valid,
    }
