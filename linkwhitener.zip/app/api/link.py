from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field, HttpUrl

from app.database.session import get_db
from app.api.deps import get_current_user
from app.services.link_service import create_link, delete_link
from app.models.user import User
from app.models.link import Link

router = APIRouter()


# -----------------------------
# SCHEMAS
# -----------------------------
class CreateLinkRequest(BaseModel):
    original_url: HttpUrl
    public_name: str | None = Field(default=None, max_length=255)


class LinkResponse(BaseModel):
    id: int
    short_code: str
    original_url: str
    public_name: str | None
    total_clicks: int
    valid_clicks: int
    invalid_clicks: int
    is_active: bool

    class Config:
        from_attributes = True


# -----------------------------
# CREATE LINK
# -----------------------------
@router.post("/create", response_model=LinkResponse)
def create_new_link(
    payload: CreateLinkRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    link = create_link(
        db=db,
        user=user,
        original_url=str(payload.original_url),
        public_name=payload.public_name,
    )
    return link


# -----------------------------
# LIST LINKS
# -----------------------------
@router.get("/my", response_model=list[LinkResponse])
def list_my_links(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    links = (
        db.query(Link)
        .filter(Link.user_id == user.id, Link.is_deleted == False)
        .order_by(Link.created_at.desc())
        .all()
    )
    return links


# -----------------------------
# DELETE LINK
# -----------------------------
@router.delete("/{link_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_link(
    link_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    delete_link(db=db, user=user, link_id=link_id)
    return None
