from app.middleware.auth import AuthContextMiddleware
from app.middleware.cors import setup_cors
from app.middleware.security import SecurityHeadersMiddleware
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from starlette.responses import JSONResponse

from app.core.config import settings
from app.core.scheduler import start_scheduler
from app.database.init_db import init_db
from app.api import auth, user, link, click, earning, withdrawal, admin

# -----------------------------
# RATE LIMITER
# -----------------------------
limiter = Limiter(key_func=get_remote_address)

# -----------------------------
# APP INIT
# -----------------------------
app = FastAPI(
    title=settings.APP_NAME,
    debug=settings.DEBUG,
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url=None,
)

# Attach limiter
app.state.limiter = limiter
app.add_middleware(SlowAPIMiddleware)

# -----------------------------
# CORS
# -----------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------
# GLOBAL RATE LIMIT ERROR
# -----------------------------
@app.exception_handler(RateLimitExceeded)
async def rate_limit_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse(
        status_code=429,
        content={"detail": "Too many requests. Slow down."},
    )

# -----------------------------
# ROUTERS
# -----------------------------
# Middleware
app.add_middleware(AuthContextMiddleware)
app.add_middleware(SecurityHeadersMiddleware)
setup_cors(app)
app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(user.router, prefix="/user", tags=["User"])
app.include_router(link.router, prefix="/link", tags=["Link"])
app.include_router(click.router, prefix="/click", tags=["Click"])
app.include_router(earning.router, prefix="/earning", tags=["Earning"])
app.include_router(withdrawal.router, prefix="/withdrawal", tags=["Withdrawal"])
app.include_router(admin.router, prefix="/admin", tags=["Admin"])

# -----------------------------
# STARTUP EVENTS
# -----------------------------
@app.on_event("startup")
async def on_startup():
    # Auto create tables
    init_db()

    # Start cleanup & backup scheduler
    start_scheduler()

# -----------------------------
# HEALTH CHECK
# -----------------------------
@app.get("/health", include_in_schema=False)
def health_check():
    return {
        "status": "ok",
        "service": settings.APP_NAME,
        "environment": settings.ENVIRONMENT,
    }
