from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

from app.core.config import settings


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Adds HTTP security headers and enforces HTTPS in production.
    """

    async def dispatch(self, request: Request, call_next):
        # Enforce HTTPS (behind proxy safe)
        if settings.ENABLE_HTTPS_ONLY:
            proto = request.headers.get("x-forwarded-proto")
            if proto and proto != "https":
                return Response(
                    content="HTTPS required",
                    status_code=403,
                )

        response = await call_next(request)

        # -----------------------------
        # SECURITY HEADERS
        # -----------------------------
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"

        # CSP (adjust if you serve frontend from same domain)
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; "
            "frame-ancestors 'none'; "
            "base-uri 'none'; "
            "form-action 'self'"
        )

        # HSTS (only if HTTPS is guaranteed)
        if settings.ENVIRONMENT == "production":
            response.headers["Strict-Transport-Security"] = (
                "max-age=63072000; includeSubDomains; preload"
            )

        return response
