from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

from app.core.security import decode_user_token, decode_admin_token


class AuthContextMiddleware(BaseHTTPMiddleware):
    """
    Attaches decoded auth context to request.state
    without enforcing access (deps still do that).
    """

    async def dispatch(self, request: Request, call_next):
        request.state.user_id = None
        request.state.admin_id = None
        request.state.token_type = None

        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ")[1]

            # Try user token
            try:
                payload = decode_user_token(token)
                request.state.user_id = payload.get("sub")
                request.state.token_type = payload.get("type")
            except Exception:
                # Try admin token
                try:
                    payload = decode_admin_token(token)
                    request.state.admin_id = payload.get("sub")
                    request.state.token_type = "admin"
                except Exception:
                    pass  # Invalid token ignored here

        response = await call_next(request)
        return response
