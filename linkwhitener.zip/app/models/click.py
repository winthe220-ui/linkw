from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
)
from sqlalchemy.sql import func

from app.database.base import Base


class Click(Base):
    __tablename__ = "clicks"

    # -----------------------------
    # PRIMARY
    # -----------------------------
    id = Column(Integer, primary_key=True)

    # -----------------------------
    # RELATION
    # -----------------------------
    link_id = Column(Integer, ForeignKey("links.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    # -----------------------------
    # VISITOR DATA
    # -----------------------------
    ip_address = Column(String(45), nullable=False)
    user_agent = Column(String(512), nullable=True)

    # -----------------------------
    # FLOW TRACKING
    # -----------------------------
    page_1 = Column(Boolean, default=False)
    page_2 = Column(Boolean, default=False)
    page_3 = Column(Boolean, default=False)
    redirect_completed = Column(Boolean, default=False)

    # -----------------------------
    # VALIDATION
    # -----------------------------
    is_valid = Column(Boolean, default=False)
    is_duplicate = Column(Boolean, default=False)

    # -----------------------------
    # META
    # -----------------------------
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # -----------------------------
    # INDEXES (CRITICAL FOR FRAUD CHECK)
    # -----------------------------
    __table_args__ = (
        Index("idx_clicks_link_ip", "link_id", "ip_address"),
        Index("idx_clicks_valid", "is_valid"),
        Index("idx_clicks_created", "created_at"),
    )
