from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
)
from sqlalchemy.sql import func

from app.database.base import Base


class Link(Base):
    __tablename__ = "links"

    # -----------------------------
    # PRIMARY
    # -----------------------------
    id = Column(Integer, primary_key=True)

    # -----------------------------
    # OWNERSHIP
    # -----------------------------
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    # -----------------------------
    # LINK DATA
    # -----------------------------
    short_code = Column(String(16), unique=True, nullable=False, index=True)
    original_url = Column(String(2048), nullable=False)
    public_name = Column(String(255), nullable=True)

    # -----------------------------
    # STATUS
    # -----------------------------
    is_active = Column(Boolean, default=True)
    is_deleted = Column(Boolean, default=False)

    # -----------------------------
    # STATS (CACHED)
    # -----------------------------
    total_clicks = Column(Integer, default=0)
    valid_clicks = Column(Integer, default=0)
    invalid_clicks = Column(Integer, default=0)

    # -----------------------------
    # META
    # -----------------------------
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )

    # -----------------------------
    # INDEXES
    # -----------------------------
    __table_args__ = (
        Index("idx_links_user_active", "user_id", "is_active"),
        Index("idx_links_created", "created_at"),
    )
