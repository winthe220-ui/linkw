from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    Float,
    Enum,
    Index,
)
from sqlalchemy.sql import func
import enum

from app.database.base import Base


# -----------------------------
# MEMBERSHIP TYPES
# -----------------------------
class MembershipType(str, enum.Enum):
    free = "free"
    pro = "pro"
    elite = "elite"


class User(Base):
    __tablename__ = "users"

    # -----------------------------
    # PRIMARY
    # -----------------------------
    id = Column(Integer, primary_key=True, index=True)

    # -----------------------------
    # IDENTITY
    # -----------------------------
    phone_number = Column(String(20), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=True, index=True)

    password_hash = Column(String(255), nullable=False)

    # -----------------------------
    # ACCOUNT STATUS
    # -----------------------------
    is_active = Column(Boolean, default=True)
    is_blocked = Column(Boolean, default=False)
    is_verified = Column(Boolean, default=False)

    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime, nullable=True)

    # -----------------------------
    # MEMBERSHIP
    # -----------------------------
    membership = Column(
        Enum(MembershipType),
        default=MembershipType.free,
        nullable=False,
    )

    # -----------------------------
    # WALLET / EARNINGS
    # -----------------------------
    balance = Column(Float, default=0.0)
    total_earned = Column(Float, default=0.0)
    total_withdrawn = Column(Float, default=0.0)

    # -----------------------------
    # SECURITY TOKENS (HASHED)
    # -----------------------------
    withdraw_token_hash = Column(String(255), nullable=True)
    reset_token_hash = Column(String(255), nullable=True)

    # -----------------------------
    # META
    # -----------------------------
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )

    # -----------------------------
    # INDEXES (PERFORMANCE)
    # -----------------------------
    __table_args__ = (
        Index("idx_users_phone_active", "phone_number", "is_active"),
        Index("idx_users_membership", "membership"),
    )
