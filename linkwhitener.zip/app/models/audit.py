from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    Index,
)
from sqlalchemy.sql import func

from app.database.base import Base


class AuditLog(Base):
    __tablename__ = "audit_logs"

    # -----------------------------
    # PRIMARY
    # -----------------------------
    id = Column(Integer, primary_key=True)

    # -----------------------------
    # ACTOR INFO
    # -----------------------------
    actor_type = Column(String(20), nullable=False)   # user / admin / system
    actor_id = Column(Integer, nullable=True)

    # -----------------------------
    # ACTION
    # -----------------------------
    action = Column(String(255), nullable=False)
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(String(512), nullable=True)

    # -----------------------------
    # META
    # -----------------------------
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # -----------------------------
    # INDEXES
    # -----------------------------
    __table_args__ = (
        Index("idx_audit_actor", "actor_type", "actor_id"),
        Index("idx_audit_created", "created_at"),
    )
