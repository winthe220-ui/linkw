from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    Index,
)
from sqlalchemy.sql import func

from app.database.base import Base


class Admin(Base):
    __tablename__ = "admins"

    # -----------------------------
    # PRIMARY
    # -----------------------------
    id = Column(Integer, primary_key=True, index=True)

    # -----------------------------
    # IDENTITY
    # -----------------------------
    username = Column(String(50), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)

    # -----------------------------
    # STATUS
    # -----------------------------
    is_active = Column(Boolean, default=True)
    is_superadmin = Column(Boolean, default=False)

    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime, nullable=True)

    # -----------------------------
    # META
    # -----------------------------
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    last_login = Column(DateTime, nullable=True)

    # -----------------------------
    # INDEXES
    # -----------------------------
    __table_args__ = (
        Index("idx_admin_username_active", "username", "is_active"),
    )
