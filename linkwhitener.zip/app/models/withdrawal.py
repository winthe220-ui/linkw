from sqlalchemy import (
    Column,
    Integer,
    Float,
    String,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
)
from sqlalchemy.sql import func

from app.database.base import Base


class Withdrawal(Base):
    __tablename__ = "withdrawals"

    # -----------------------------
    # PRIMARY
    # -----------------------------
    id = Column(Integer, primary_key=True)

    # -----------------------------
    # RELATION
    # -----------------------------
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    # -----------------------------
    # AMOUNT
    # -----------------------------
    amount = Column(Float, nullable=False)

    # -----------------------------
    # PAYMENT INFO (KYC)
    # -----------------------------
    upi_id = Column(String(255), nullable=True)
    bank_account = Column(String(255), nullable=True)

    # -----------------------------
    # STATUS
    # -----------------------------
    is_approved = Column(Boolean, default=False)
    is_rejected = Column(Boolean, default=False)
    processed_by_admin = Column(String(50), nullable=True)

    # -----------------------------
    # META
    # -----------------------------
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    processed_at = Column(DateTime, nullable=True)

    # -----------------------------
    # INDEXES
    # -----------------------------
    __table_args__ = (
        Index("idx_withdrawals_user", "user_id"),
        Index("idx_withdrawals_status", "is_approved", "is_rejected"),
        Index("idx_withdrawals_created", "created_at"),
    )
