from sqlalchemy import (
    Column,
    Integer,
    Float,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
)
from sqlalchemy.sql import func

from app.database.base import Base


class Earning(Base):
    __tablename__ = "earnings"

    # -----------------------------
    # PRIMARY
    # -----------------------------
    id = Column(Integer, primary_key=True)

    # -----------------------------
    # RELATION
    # -----------------------------
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    link_id = Column(Integer, ForeignKey("links.id", ondelete="SET NULL"), nullable=True)

    # -----------------------------
    # AMOUNT
    # -----------------------------
    amount = Column(Float, nullable=False)
    clicks_count = Column(Integer, nullable=False)

    # -----------------------------
    # STATUS
    # -----------------------------
    is_paid = Column(Boolean, default=False)

    # -----------------------------
    # META
    # -----------------------------
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # -----------------------------
    # INDEXES
    # -----------------------------
    __table_args__ = (
        Index("idx_earnings_user", "user_id"),
        Index("idx_earnings_paid", "is_paid"),
        Index("idx_earnings_created", "created_at"),
    )
