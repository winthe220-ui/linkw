from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.pool import QueuePool

from app.core.config import settings

# -----------------------------
# DATABASE ENGINE
# -----------------------------
engine = create_engine(
    settings.DATABASE_URL,
    poolclass=QueuePool,
    pool_size=20,          # concurrent connections
    max_overflow=30,       # extra burst connections
    pool_timeout=30,
    pool_recycle=1800,     # recycle connections every 30 min
    echo=False,            # NEVER True in production
)

# -----------------------------
# SESSION FACTORY
# -----------------------------
SessionLocal = scoped_session(
    sessionmaker(
        autocommit=False,
        autoflush=False,
        bind=engine,
    )
)

# -----------------------------
# DEPENDENCY
# -----------------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
