from app.database.session import engine
from app.database.base import Base

# Import ALL models here
from app.models.user import User
from app.models.admin import Admin
from app.models.link import Link
from app.models.click import Click
from app.models.earning import Earning
from app.models.withdrawal import Withdrawal
from app.models.audit import AuditLog


def init_db():
    """
    Create database tables if they don't exist.
    Safe to call multiple times.
    """
    Base.metadata.create_all(bind=engine)
