Replace ALL CHANGE_THIS_... values with long random strings
openssl rand -hex 64


# LinkWhitener Backend

Production-grade backend for link monetization & traffic validation.

## Tech Stack
- FastAPI
- PostgreSQL
- SQLAlchemy 2.x
- Alembic
- JWT Auth
- APScheduler
- AWS EC2 Ready

## Features
- Secure user & admin authentication
- JWT + withdraw token system
- 3-page anti-fraud click validation
- Earnings & manual withdrawal approval
- Admin control panel
- Automatic cleanup (48h data, 30d audits)
- Rate limiting & security headers

## Setup

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
